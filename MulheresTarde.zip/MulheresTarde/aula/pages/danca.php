<?php
  require_once 'head.php';
  require_once 'menu.php';
  ?>

<<div class="container-fluid text-center conteudo">
        <div class="row">
          <div class="col-md-6 texto">
            <img src="imagens/academia7.jpg" class="img-fluid">
          </div>
          <div class="col-md-6">
            <h5>Danças</h5>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Non molestias dolores architecto porro sunt deleniti hic facere, eveniet omnis est quae saepe mollitia optio fugiat esse, quod dolorem expedita cumque?</p>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi porro repudiandae ea rerum ullam molestias enim exercitationem eveniet assumenda. Ipsum repellendus delectus est ratione exercitationem quod odit vel cum a!</p>
          </div>
  <?php
  require_once 'footer.php';
  ?>