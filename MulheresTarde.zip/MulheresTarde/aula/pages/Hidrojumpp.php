<?php
  require_once 'head.php';
  require_once 'menu.php';
  ?>

<div class="row">
        <div class="col-md-6">
            <h4>Hidro Jumpp</h4>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sapiente voluptates tenetur dolorem omnis, quidem id eaque ullam ipsam modi adipisci enim hic? Obcaecati incidunt quae illo, saepe reprehenderit consequatur voluptatem?</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum a iste suscipit voluptas voluptatum quia in reprehenderit aspernatur illum. Tempora ex quos consequuntur rerum iure nobis deserunt sapiente maiores quae.</p>
          </div>
          <div class="col-md-6">
            <img src="imagens/academia6.jpg" class="img-fluid">
          </div>
      </div>

  <?php
  require_once 'footer.php';
  ?>