<?php
  require_once 'head.php';
  require_once 'menu.php';
  ?>

<div class="container-fluid text-center conteudo">
      <div class="row">
        <div class="col-md-6 texto">
          <img src="imagens/academia5.jpg" class="img-fluid">
        </div>
        <div class="col-md-6">
          <h3>Jumpp</h3>
         <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. A sapiente totam quam repellendus veniam aliquid? Ipsam, amet. Laborum illum ab similique officia, mollitia nemo quam commodi perferendis, laboriosam molestias nobis?<p>
          <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Incidunt nobis in facilis. Ad deleniti voluptatem dolorem ut distinctio alias recusandae quae et suscipit rem eaque eligendi sit possimus, in voluptas.</p>
        </div>
      </div>

  <?php
  require_once 'footer.php';
  ?>