<?php
  require_once 'head.php';
  require_once 'menu.php';
  ?>


    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 text-center">
                <img src="imagens/academia3.jpg" class="img-fluid">
            </div>

        </div>
    </div>


      <div class="container-fluid">
        <div class="row">
        <div class="col-md-12 text-center">
          <h2>Conheça um pouco das nossas atividades </h2>
        </div>
        </div>
      </div>
           
    <div class="container-fluid imagens">
        <div class="row">
            <div class="col-md-4">
                <img src="imagens/academia1.jpg" class="img-fluid">
            </div>

            <div class="col-md-4">
                <img src="imagens/academia2.jpg" class="img-fluid">
            </div>

            <div class="col-md-4">
                <img src="imagens/academia4.webp" class="img-fluid">
            </div>

        </div>
    </div>
    <div class="container-fluid text-center conteudo">
      <div class="row">
        <div class="col-md-6 texto">
          <img src="imagens/academia5.jpg" class="img-fluid">
        </div>
        <div class="col-md-6">
          <h3>Jumpp</h3>
         <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. A sapiente totam quam repellendus veniam aliquid? Ipsam, amet. Laborum illum ab similique officia, mollitia nemo quam commodi perferendis, laboriosam molestias nobis?<p>
          <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Incidunt nobis in facilis. Ad deleniti voluptatem dolorem ut distinctio alias recusandae quae et suscipit rem eaque eligendi sit possimus, in voluptas.</p>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
            <h4>Hidro Jumpp</h4>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sapiente voluptates tenetur dolorem omnis, quidem id eaque ullam ipsam modi adipisci enim hic? Obcaecati incidunt quae illo, saepe reprehenderit consequatur voluptatem?</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum a iste suscipit voluptas voluptatum quia in reprehenderit aspernatur illum. Tempora ex quos consequuntur rerum iure nobis deserunt sapiente maiores quae.</p>
          </div>
          <div class="col-md-6">
            <img src="imagens/academia6.jpg" class="img-fluid">
          </div>
      </div>
      <div class="container-fluid text-center conteudo">
        <div class="row">
          <div class="col-md-6 texto">
            <img src="imagens/academia7.jpg" class="img-fluid">
          </div>
          <div class="col-md-6">
            <h5>Danças</h5>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Non molestias dolores architecto porro sunt deleniti hic facere, eveniet omnis est quae saepe mollitia optio fugiat esse, quod dolorem expedita cumque?</p>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi porro repudiandae ea rerum ullam molestias enim exercitationem eveniet assumenda. Ipsum repellendus delectus est ratione exercitationem quod odit vel cum a!</p>
          </div>
          
         <?php 
         require_once 'footer.php';
           ?>
       
      

        





    